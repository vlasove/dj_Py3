* ***GitHub*** : https://github.com/vlasove/dj_Py3

* ***Contest*** : https://contest.yandex.ru/contest/19917