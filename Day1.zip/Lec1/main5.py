lst = [10, 20, 30, 40]
lst[:2] = [10000, 20000, 300000, 40000] 

print('lst:', lst)
#print('lst2:', lst2)
