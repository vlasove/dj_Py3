name = "Hello world"
for i in range(0, len(name)):
    print(i, "letter",  name[i])

name[len(name) - 1] == name[-1]

hello = name[0:5:1]