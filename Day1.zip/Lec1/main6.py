message = "hi i am bob \tand\n\n\n u              are not bob"
words = message.split()
print(words)

print("# #".join(words))